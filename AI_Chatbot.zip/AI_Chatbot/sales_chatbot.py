import os
import pandas as pd
from dotenv import load_dotenv
import openai
from sklearn.ensemble import IsolationForest
import glob

# Load OpenAI API key
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# -------------------------------------------
# READ ALL EXCEL FILES (skip ~$ lock files)
# -------------------------------------------
data_folder = "sales_data"

all_files = [
    f for f in glob.glob(os.path.join(data_folder, "*.xlsx"))
    if "~$" not in f
]

df_list = [pd.read_excel(f) for f in all_files]
df = pd.concat(df_list, ignore_index=True)

# -------------------------------------------
# LOAD Q&A CSV FOR CHATBOT (clean columns)
# -------------------------------------------
qa_df = pd.read_csv("qa_output.csv")

# Remove unnamed columns
qa_df = qa_df.loc[:, ~qa_df.columns.str.contains('^Unnamed')]

# Ensure only Question + Answer remain
qa_df = qa_df[['Question', 'Answer']]

qa_df.columns = qa_df.columns.str.strip()  # remove spaces

print("Loaded Q&A columns:", qa_df.columns)

def ask_ai(question):
    answer = qa_df.loc[qa_df['Question'].str.lower() == question.lower(), 'Answer']
    if not answer.empty:
        return answer.values[0]
    else:
        return "Sorry, I don't have an answer for that question."

# -------------------------------------------
# AI ANOMALY DETECTION FUNCTION
# -------------------------------------------
def run_anomaly_detection():

    print("\n🔍 Running AI Anomaly Detection...\n")

    # Column validation
    if "norm_sales_amount" not in df.columns:
        print("❌ Column 'norm_sales_amount' missing in Excel data.")
        return

    if "markets_name" not in df.columns:
        print("❌ Column 'markets_name' missing in Excel data.")
        return

    if "date" not in df.columns:
        print("❌ Column 'date' missing in Excel data.")
        return

    # Revenue rename
    df["revenue"] = df["norm_sales_amount"]

    # Group by date + market
    sales_df = df.groupby(["date", "markets_name"], as_index=False)["revenue"].sum()

    # Isolation Forest model
    model = IsolationForest(contamination=0.05, random_state=42)
    sales_df["anomaly"] = model.fit_predict(sales_df[["revenue"]])

    anomalies = sales_df[sales_df["anomaly"] == -1]

    print("\n🚨 DETECTED ANOMALIES:")
    print(anomalies)

    print("\n✔ Anomaly Detection Completed.\n")

    return anomalies

# -------------------------------------------
# CHATBOT LOOP
# -------------------------------------------
def chat():
    print("Sales Chatbot (type 'anomaly' to detect anomalies, 'exit' to quit)")
    while True:
        question = input("You: ")

        if question.lower() == "exit":
            print("Goodbye!")
            break

        elif question.lower() == "anomaly":
            run_anomaly_detection()
            continue

        try:
            answer = ask_ai(question)
            print(f"AI: {answer}\n")
        except Exception as e:
            print(f"Error: {e}")

# -------------------------------------------
# MAIN EXECUTION
# -------------------------------------------
if __name__ == "__main__":
    chat()

