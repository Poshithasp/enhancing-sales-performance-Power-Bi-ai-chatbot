USE sales;
SHOW TABLES;
SELECT COUNT(*) FROM customers;
SELECT COUNT(*) FROM markets;
SELECT COUNT(*) FROM products;
SELECT COUNT(*) FROM transactions;
